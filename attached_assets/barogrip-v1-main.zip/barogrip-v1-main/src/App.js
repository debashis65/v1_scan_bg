import React, { useState, useEffect, createContext, useContext } from 'react';
import { User, UserPlus, Calendar, FileText, Users, Activity, LogOut, Plus, Search, Edit, Trash2 } from 'lucide-react';

// Authentication Context
const AuthContext = createContext();

const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Mock Database
const mockUsers = [
  { id: 1, name: 'Dr. Sarah Johnson', email: 'dr.johnson@hospital.com', role: 'doctor', specialization: 'Cardiology', phone: '+1-555-0101' },
  { id: 2, name: 'John Doe', email: 'john.doe@email.com', role: 'patient', dateOfBirth: '1985-06-15', phone: '+1-555-0102' },
  { id: 3, name: 'Dr. Michael Chen', email: 'dr.chen@hospital.com', role: 'doctor', specialization: 'Neurology', phone: '+1-555-0103' },
  { id: 4, name: 'Jane Smith', email: 'jane.smith@email.com', role: 'patient', dateOfBirth: '1990-03-22', phone: '+1-555-0104' },
];

const mockAppointments = [
  { id: 1, patientId: 2, doctorId: 1, date: '2025-05-15', time: '10:00', status: 'scheduled', notes: 'Regular checkup' },
  { id: 2, patientId: 4, doctorId: 3, date: '2025-05-16', time: '14:30', status: 'completed', notes: 'Follow-up consultation' },
  { id: 3, patientId: 2, doctorId: 1, date: '2025-05-20', time: '09:00', status: 'scheduled', notes: 'Lab results review' },
];

const mockMedicalRecords = [
  { id: 1, patientId: 2, doctorId: 1, date: '2025-05-10', diagnosis: 'Hypertension', treatment: 'Medication prescribed', notes: 'Monitor blood pressure regularly' },
  { id: 2, patientId: 4, doctorId: 3, date: '2025-05-12', diagnosis: 'Migraine', treatment: 'Pain management', notes: 'Stress-related headaches' },
];

// AuthProvider Component
const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  const login = (email, password) => {
    console.log('Login attempt:', email, password);
    console.log('Available users:', mockUsers);
    const foundUser = mockUsers.find(u => u.email === email);
    console.log('Found user:', foundUser);
    if (foundUser && password === 'password123') {
      setUser(foundUser);
      console.log('Login successful, user set:', foundUser);
      return { success: true };
    }
    return { success: false, error: 'Invalid credentials' };
  };

  const register = (userData) => {
    const newUser = {
      id: mockUsers.length + 1,
      ...userData,
    };
    return { success: true, user: newUser };
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

// Login Component
const Login = ({ onSwitchToRegister }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();

  const handleLogin = () => {
    console.log('Submitting login with:', email, password);
    const result = login(email, password);
    console.log('Login result:', result);
    if (!result.success) {
      setError(result.error || 'Login failed');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
      <div className="max-w-md w-full space-y-8">
        <div>
          <div className="mx-auto h-12 w-12 flex items-center justify-center rounded-full bg-blue-100">
            <User className="h-6 w-6 text-blue-600" />
          </div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Sign in to your account
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Demo: dr.johnson@hospital.com / password123
          </p>
        </div>
        <div className="mt-8 space-y-6">
          <div className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email address
              </label>
              <input
                id="email"
                type="email"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                Password
              </label>
              <input
                id="password"
                type="password"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          {error && (
            <div className="text-red-600 text-sm text-center">{error}</div>
          )}

          <button
            type="button"
            onClick={handleLogin}
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Sign in
          </button>

          <div className="text-center">
            <button
              type="button"
              onClick={onSwitchToRegister}
              className="font-medium text-blue-600 hover:text-blue-500"
            >
              Don't have an account? Sign up
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Register Component
const Register = ({ onSwitchToLogin }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: 'patient',
    specialization: '',
    dateOfBirth: '',
    phone: ''
  });
  const { register } = useAuth();

  const handleRegister = () => {
    const result = register(formData);
    if (result.success) {
      onSwitchToLogin();
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
      <div className="max-w-md w-full space-y-8">
        <div>
          <div className="mx-auto h-12 w-12 flex items-center justify-center rounded-full bg-green-100">
            <UserPlus className="h-6 w-6 text-green-600" />
          </div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Create your account
          </h2>
        </div>
        <div className="mt-8 space-y-6">
          <div className="space-y-4">
            <input
              name="name"
              type="text"
              placeholder="Full Name"
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              value={formData.name}
              onChange={handleChange}
            />
            <input
              name="email"
              type="email"
              placeholder="Email"
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              value={formData.email}
              onChange={handleChange}
            />
            <input
              name="password"
              type="password"
              placeholder="Password"
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              value={formData.password}
              onChange={handleChange}
            />
            <select
              name="role"
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              value={formData.role}
              onChange={handleChange}
            >
              <option value="patient">Patient</option>
              <option value="doctor">Doctor</option>
            </select>
            {formData.role === 'doctor' && (
              <input
                name="specialization"
                type="text"
                placeholder="Specialization"
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                value={formData.specialization}
                onChange={handleChange}
              />
            )}
            {formData.role === 'patient' && (
              <input
                name="dateOfBirth"
                type="date"
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                value={formData.dateOfBirth}
                onChange={handleChange}
              />
            )}
            <input
              name="phone"
              type="tel"
              placeholder="Phone Number"
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              value={formData.phone}
              onChange={handleChange}
            />
          </div>

          <button
            type="button"
            onClick={handleRegister}
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
          >
            Sign up
          </button>

          <div className="text-center">
            <button
              type="button"
              onClick={onSwitchToLogin}
              className="font-medium text-blue-600 hover:text-blue-500"
            >
              Already have an account? Sign in
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Header Component
const Header = () => {
  const { user, logout } = useAuth();

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center py-6">
          <div className="flex items-center">
            <Activity className="h-8 w-8 text-blue-600" />
            <h1 className="ml-2 text-2xl font-bold text-gray-900">MedManager</h1>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-700">{user?.name} ({user?.role})</span>
            <button
              onClick={logout}
              className="inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700"
            >
              <LogOut className="h-4 w-4 mr-1" />
              Logout
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

// Navigation Component
const Navigation = ({ activeTab, setActiveTab, userRole }) => {
  const doctorTabs = [
    { id: 'dashboard', label: 'Dashboard', icon: Activity },
    { id: 'patients', label: 'Patients', icon: Users },
    { id: 'appointments', label: 'Appointments', icon: Calendar },
    { id: 'records', label: 'Medical Records', icon: FileText },
  ];

  const patientTabs = [
    { id: 'dashboard', label: 'Dashboard', icon: Activity },
    { id: 'appointments', label: 'My Appointments', icon: Calendar },
    { id: 'records', label: 'My Records', icon: FileText },
  ];

  const tabs = userRole === 'doctor' ? doctorTabs : patientTabs;

  return (
    <nav className="bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex space-x-8">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center px-1 py-4 text-sm font-medium border-b-2 ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <Icon className="h-4 w-4 mr-2" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};

// Dashboard Component
const Dashboard = ({ userRole }) => {
  const { user } = useAuth();
  
  if (userRole === 'doctor') {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-semibold text-gray-900">Doctor Dashboard</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <Users className="h-6 w-6 text-gray-400" />
                <div className="ml-5">
                  <p className="text-sm font-medium text-gray-500">Total Patients</p>
                  <p className="text-lg font-medium text-gray-900">
                    {mockUsers.filter(u => u.role === 'patient').length}
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <Calendar className="h-6 w-6 text-gray-400" />
                <div className="ml-5">
                  <p className="text-sm font-medium text-gray-500">Today's Appointments</p>
                  <p className="text-lg font-medium text-gray-900">
                    {mockAppointments.filter(apt => apt.doctorId === user.id).length}
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="p-5">
              <div className="flex items-center">
                <FileText className="h-6 w-6 text-gray-400" />
                <div className="ml-5">
                  <p className="text-sm font-medium text-gray-500">Records Created</p>
                  <p className="text-lg font-medium text-gray-900">
                    {mockMedicalRecords.filter(r => r.doctorId === user.id).length}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Patient Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <Calendar className="h-6 w-6 text-gray-400" />
              <div className="ml-5">
                <p className="text-sm font-medium text-gray-500">Upcoming Appointments</p>
                <p className="text-lg font-medium text-gray-900">
                  {mockAppointments.filter(apt => apt.patientId === user.id && apt.status === 'scheduled').length}
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <FileText className="h-6 w-6 text-gray-400" />
              <div className="ml-5">
                <p className="text-sm font-medium text-gray-500">Medical Records</p>
                <p className="text-lg font-medium text-gray-900">
                  {mockMedicalRecords.filter(r => r.patientId === user.id).length}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Patients Component
const Patients = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const filteredPatients = mockUsers.filter(u => u.role === 'patient');

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Patients</h1>
        <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
          <Plus className="h-4 w-4 mr-2" />
          Add Patient
        </button>
      </div>
      
      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {filteredPatients.map((patient) => (
            <li key={patient.id}>
              <div className="px-4 py-4 flex items-center justify-between">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center">
                    <User className="h-6 w-6 text-gray-600" />
                  </div>
                  <div className="ml-4">
                    <div className="text-sm font-medium text-gray-900">{patient.name}</div>
                    <div className="text-sm text-gray-500">{patient.email}</div>
                    <div className="text-sm text-gray-500">DOB: {patient.dateOfBirth}</div>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button className="text-blue-600 hover:text-blue-900">
                    <Edit className="h-4 w-4" />
                  </button>
                  <button className="text-red-600 hover:text-red-900">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

// Appointments Component
const Appointments = ({ userRole }) => {
  const { user } = useAuth();
  const filteredAppointments = mockAppointments.filter(apt => 
    userRole === 'doctor' ? apt.doctorId === user.id : apt.patientId === user.id
  );

  const getPatientName = (patientId) => {
    const patient = mockUsers.find(u => u.id === patientId);
    return patient ? patient.name : 'Unknown';
  };

  const getDoctorName = (doctorId) => {
    const doctor = mockUsers.find(u => u.id === doctorId);
    return doctor ? doctor.name : 'Unknown';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">
          {userRole === 'doctor' ? 'Appointments' : 'My Appointments'}
        </h1>
        <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
          <Plus className="h-4 w-4 mr-2" />
          {userRole === 'doctor' ? 'Schedule Appointment' : 'Book Appointment'}
        </button>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {filteredAppointments.map((appointment) => (
            <li key={appointment.id}>
              <div className="px-4 py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Calendar className="h-6 w-6 text-blue-500 mr-3" />
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {userRole === 'doctor' ? getPatientName(appointment.patientId) : getDoctorName(appointment.doctorId)}
                      </div>
                      <div className="text-sm text-gray-500">
                        {appointment.date} at {appointment.time}
                      </div>
                      <div className="text-sm text-gray-500">{appointment.notes}</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      appointment.status === 'scheduled' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'
                    }`}>
                      {appointment.status}
                    </span>
                    <div className="flex space-x-2">
                      <button className="text-blue-600 hover:text-blue-900">
                        <Edit className="h-4 w-4" />
                      </button>
                      <button className="text-red-600 hover:text-red-900">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

// Medical Records Component
const MedicalRecords = ({ userRole }) => {
  const { user } = useAuth();
  const filteredRecords = mockMedicalRecords.filter(record => 
    userRole === 'doctor' ? record.doctorId === user.id : record.patientId === user.id
  );

  const getPatientName = (patientId) => {
    const patient = mockUsers.find(u => u.id === patientId);
    return patient ? patient.name : 'Unknown';
  };

  const getDoctorName = (doctorId) => {
    const doctor = mockUsers.find(u => u.id === doctorId);
    return doctor ? doctor.name : 'Unknown';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">
          {userRole === 'doctor' ? 'Medical Records' : 'My Medical Records'}
        </h1>
        {userRole === 'doctor' && (
          <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-2" />
            Add Record
          </button>
        )}
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {filteredRecords.map((record) => (
            <li key={record.id}>
              <div className="px-4 py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <FileText className="h-6 w-6 text-green-500 mr-3" />
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {userRole === 'doctor' ? getPatientName(record.patientId) : getDoctorName(record.doctorId)}
                      </div>
                      <div className="text-sm text-gray-500">Date: {record.date}</div>
                      <div className="text-sm text-gray-900 font-medium">Diagnosis: {record.diagnosis}</div>
                      <div className="text-sm text-gray-700">Treatment: {record.treatment}</div>
                      <div className="text-sm text-gray-600">Notes: {record.notes}</div>
                    </div>
                  </div>
                  {userRole === 'doctor' && (
                    <div className="flex space-x-2">
                      <button className="text-blue-600 hover:text-blue-900">
                        <Edit className="h-4 w-4" />
                      </button>
                      <button className="text-red-600 hover:text-red-900">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

// Main App Component
const App = () => {
  const [authMode, setAuthMode] = useState('login');
  const [activeTab, setActiveTab] = useState('dashboard');
  const { user } = useAuth();

  if (!user) {
    return (
      <div>
        {authMode === 'login' ? (
          <Login onSwitchToRegister={() => setAuthMode('register')} />
        ) : (
          <Register onSwitchToLogin={() => setAuthMode('login')} />
        )}
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard userRole={user.role} />;
      case 'patients':
        return user.role === 'doctor' ? <Patients /> : null;
      case 'appointments':
        return <Appointments userRole={user.role} />;
      case 'records':
        return <MedicalRecords userRole={user.role} />;
      default:
        return <Dashboard userRole={user.role} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <Navigation 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        userRole={user.role} 
      />
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

// Root App with Auth Provider
const AppWithAuth = () => {
  return (
    <AuthProvider>
      <App />
    </AuthProvider>
  );
};

export default AppWithAuth;