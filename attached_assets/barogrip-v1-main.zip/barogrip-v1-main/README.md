# Doctor/Patient Management App

A React-based healthcare management system with role-based authentication for doctors and patients.

## Features

- **Role-based Authentication**: Separate login for doctors and patients
- **Doctor Dashboard**: Manage patients, appointments, and medical records
- **Patient Dashboard**: View personal appointments and medical records
- **Responsive Design**: Built with Tailwind CSS
- **Mock Data**: Uses in-memory data (easily replaceable with real database)

## Demo Credentials

**Doctor Account:**
- Email: `dr.johnson@hospital.com`
- Password: `password123`

**Patient Account:**
- Email: `john.doe@email.com`
- Password: `password123`

## Installation

1. Clone or download the project files
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm start
   ```
4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Project Structure

```
doctor-patient-app/
├── public/
│   └── index.html
├── src/
│   ├── App.js
│   └── index.js
├── package.json
└── README.md
```

## Built With

- React 18
- Tailwind CSS
- Lucide React (for icons)
- Create React App

## Future Enhancements

- PostgreSQL database integration
- Real authentication with JWT
- Appointment scheduling system
- File upload for medical records
- Email notifications
- Search and filtering features

## License

This project is for demonstration purposes.